from telegram.ext import ConversationHandler

TOKEN = '6819547299:AAGV8QjGr5kXnatZOnGXmQejH5FFPVYlsII'
MONGO_URI = 'mongodb+srv://yanghan:yh123456@yh.psdsh48.mongodb.net/?retryWrites=true&w=majority&appName=yh'
GPT_KEY = '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'

